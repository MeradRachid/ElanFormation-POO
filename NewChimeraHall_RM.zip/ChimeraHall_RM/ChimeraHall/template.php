<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/style.css">
    <title>Chimera Hall</title>
</head>
<body>
    <div id="BodyWrap">
        <header id="Header">
            <nav>
                <img src="public/img/moon.jpg" alt="ChimeraHall" id="Logo">
                <ul id="Navbar" class="no-bullet">
                    <h1> ChimeraHall </h1>
                    <button id="Homepage"> Accueil </button>
                    <button id="Naviguation"> Explore la zone </button>
                    <button id="Login"> Connecte-toi </button>
                    <button id="Register"> REJOINS-NOUS !!! </button>
                </ul>
            </nav>
                        <!-- c'est ici que les messages (erreur ou succès) s'affichent-->
                        <h3 class="message" style="color: red"><?/* App\Session::getFlash("error") */?></h3>
                        <h3 class="message" style="color: green"><?/* App\Session::getFlash("success") */?></h3>
        </header>
        <main>
            <section id="home1">
                <div id="homeExplore">
                    <form action="#" method="post" id="SearchBar">
                        <input list="Search" placeholder=" Que recherchez-vous.. ? " id="Search1">
                        <datalist id="Search">
                                <option value="Edge">
                                <option value="Firefox">
                                <option value="Chrome">
                                <option value="Opera">
                                <option value="Safari">
                        </datalist>
                        <select name="types" id="Search2">
                            <optgroup id="type">
                                <option selected> Tous les Types d'Events : </option>
                                <option value="freeFight" id="1"># : Match Amical </option>
                                <option value="Coaching" id="2"># : Coaching </option>
                                <option value="Tournoi" id="3"># : Tournoi </option>
                            </optgroup>
                        </select>
                        <select name="formats" id="Search3">
                            <optgroup id="format">
                                <option selected> Tous les Formats de Jeux : </option>
                                <option value="standard" id="1"># : Standard </option>
                                <option value="modern" id="2"># : Modern </option>
                                <option value="legacy" id="3"># : Legacy </option>
                            </optgroup>
                        </select>
                        <button type="submit" id="SearchButton">Rechercher</button>
                    </form>
                </div>
                <div id="spotlight">
                    <figure class="spotlight" id="rally">
                        <figcaption>
                            Dernier point de ralliement créé : 
                        </figcaption>
                        <img src="public/img/rallyPointWexim.png" alt="Last RallyPoint Spotlight">
                    </figure>
                    <figure class="spotlight" id="unite">
                        <figcaption>
                            Dernier Planeswalker inscrit : 
                        </figcaption>
                        <img src="public/img/yurikoh.png" alt="Last Registered Spotlight">
                    </figure>
                    <figure class="spotlight" id="spawn">
                        <figcaption>
                            Dernier évènement créé : 
                        </figcaption>
                        <img src="public/img/lifeWorkCreate.png" alt="Last Event Spotlight">
                    </figure>
                </div>
            </section>
            <section id="home2">

            </section>
        </main>
        <footer>

        </footer>
    </div>
</body>
</html>