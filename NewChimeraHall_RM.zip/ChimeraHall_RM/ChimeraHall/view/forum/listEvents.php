<?php
    $events = $result["data"]['events'];
    $event_id = 1;

    // var_dump($event); 
?>

    <h1>~ Bienvenue sur List Events ~</h1>

    <form action="index.php?ctrl=forum&action=eventForm" method="post" enctype="multipart">
        <button type="submit" class="rounded p-1 border-success" style="max-width: 18rem;">Publier une annonce</button>
    </form>

    <ul class="d-flex justify-content-center">
        
        <?php
            foreach($events as $event)
            {
        ?>
                <div class="card border-success m-1 text-center" style="max-width: 30rem;">
                    <div class="card-header bg-transparent border-success"> <?=$event->getType()->getTitle()?> - <?=$event->getFormat()->getLabel()?> : <?=$event->getDateTime()?> </div>
                    <div class="card-body text-success">
                        <h5 class="card-title"><a href="index.php?ctrl=forum&action=detailEvent&id=<?=$event->getId()?>" class="text-reset text-decoration-none"> <?=$event->getName()?> </a></h5>
                    </div>

                    <div class="card-footer bg-transparent border-success">
                        <?php 
                            if(App\Session::isAdmin() || $event->getUser()->getId() == App\Session::getUser()->getId())
                            {
                                if($event->getEventLocked() == true)
                                {
                                    echo '<a href="#" class="m-1"><img src="public/img/lock-solid.svg" width="30%" height="30%" alt="trash"></a>';
                                }
                                else
                                {
                                    echo '<a href="index.php?ctrl=forum&action=updateForm&id='.$event->getId().'" class="m-1"> <i class="fas fa-pencil-alt"></i></a> <a href="#" class="m-1"><span class="fas fa-lock-open mx-3"></span></a> <a href="index.php?ctrl=forum&action=deleteEvent&id='.$event->getId().'" class="m-1"> <i class="fas fa-trash-alt" width="25%" height="25%" alt="penToSquare"></i></a>';
                                }
                            }
                        ?>  
                        <br> <a href="index.php?ctrl=forum&action=detailUser&id=<?=$event->getUser()->getId()?>" class="text-decoration-none">By : <?= $event->getUser()->getPseudo() ?> </a> 
                    </div>
                </div>
        <?php
            $event_id++;
        }    
        ?>

    </ul>
