<?php
    use Model\Managers\ParticipationManager;

    $event = $result["data"]['event'];
    $reservation = $result["data"]['reservations'];
    $format_id = $result["data"]['format_id'];  

    // On récupère le nombre de participations pour cet événement
    $participationManager = new ParticipationManager();
    $nbParticipations = $participationManager->countParticipations($event->getId());

?>

    <h1>~ Bienvenue ~</h1>

    <h2 class="text-center"> Détail de l'event <?=$event->getName()?> </h2>

    <ul>
        <li>
            Identifiant Event : # <?=$event->getId()?>
        </li>

        <li>
            Prévue le : <?=$event->getDateTime()?>H
        </li>

        <li>
            Adresse : <?=$event->getAdress()?>, <?=$event->getZipCode()?> <?=$event->getCity()?>
        </li>

        <li>
            Type d'évent : # <?=$event->getType()->getId()?> > <?=$event->getType()->getTitle()?>
        </li>

        <li>
             Format de jeu : # <?=$format_id?> > <?=$event->getFormat()->getLabel()?> 
        </li>

        <li>
            <?php echo 'Nombre de Participants Actuel : '.$nbParticipations.' / '; if($event->getNbMaxPlayer() == 0) { echo 'Sans Limite';} else {echo $event->getNbMaxPlayer();} ?>  
        </li>

        <li>
            Organisateur : <?=$event->getUser()->getPseudo()?>
        </li>
        
    </ul>

    <form action="index.php?ctrl=forum&action=addParticipation&id=<?=$event->getId()?>" method="post">
        <?php
            if($nbParticipations == $event->getNbMaxPlayer())
            {
                echo  '<button type="submit" class="rounded p-1 border-success" style="max-width: 18rem;" disabled>Évènement Complet</button>';
            }
            else
            {
                echo '<button type="submit" class="rounded p-1 border-success" style="max-width: 18rem;">Participer à l\'évènement</button>';
            }
        ?>
    </form>
<br>
     

