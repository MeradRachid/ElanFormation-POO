    
    <h1 class="text-center">~ Bienvenue ~</h1>
    <h2 class="text-center"> Accueil du Forum</h2>


<div class="d-flex">
    <div class="card m-3" style="max-width: 540px;">
        <div class="row g-0">
            <div class="col-md-4 d-flex align-items-center justify-content-center">
                <img src="public/img/layerGroup.svg"  width="75%" height="75%" class="img-fluid rounded-start" alt="Category">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                <h5 class="card-title"><a href="template.php" class="text-decoration-none">Voir toutes les catégories : </a></h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-muted">Last updated 15 mins ago</small></p>
                </div>
            </div>
        </div>
    </div>

    <div>
    <a href="index.php?ctrl=forum&action=listEvents"><img src="public/img/Standard.png" class="img-fluid rounded-start"></a>
    </div>

    <div class="card m-3" style="max-width: 540px;">
        <div class="row g-0">
            <div class="col-md-4 d-flex align-items-center justify-content-center">
                <img src="public/img/layerGroup.svg"  width="75%" height="75%" class="img-fluid rounded-start" alt="Category">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                <h5 class="card-title"><a href="#" class="text-decoration-none">Voir la liste des topics : </a></h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                </div>
            </div>
        </div>
    </div>
</div>