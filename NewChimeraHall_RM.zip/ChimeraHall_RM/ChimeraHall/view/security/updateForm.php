<?php
$id = $_GET['id'];
$types = $result["data1"]['types'];
$formats = $result["data2"]['formats'];
$iDn = 1;
?>

<div class="d-flex justify-content-center">

    <form action="index.php?ctrl=forum&action=updateEvent&id=<?= $id ?>" method="POST" class="d-flex flex-column m-3">

        <input type="text" name="name" placeholder=" Event Name " class="rounded p-1 m-3 text-center" required>

        <div class="input-group mb-3">
            <select name="type_id" class="form-select form-select-sm text-center" aria-label="form-select-sm example" required>
                <option selected> Event Type </option>
                <?php                
                    foreach($types as $type)
                    { 
                ?>
                     <option value="<?=$type->getId()?>"> # <?=$type->getId()?> : <?= $type->getTitle() ?> </option>
                <?php
                    }
                ?>
            </select>
        </div>

        <div class="input-group mb-3">
            <select name="format_id" class="form-select form-select-sm text-center" aria-label="form-select-sm example" required>
                <option selected> Event Format </option>
                <?php                
                    foreach($formats as $format)
                    { 
                ?>
                     <option value="<?= $iDn ?>"> # <?= $iDn ?> : <?= $format->getLabel() ?> </option>
                <?php
                    $iDn++; 
                    }
                ?>
            </select>
        </div>

        <input type="date" id="event_date" name="date" placeholder=" Newest Date " class="rounded p-1 m-1 text-center">
        <input type="time" id="event_time" name="Time" placeholder=" Newest Time " class="rounded p-1 m-1 text-center">
        <input type="text" name="adress" placeholder=" Newest Place " class="rounded p-1 m-1 text-center" required>
        <input type="text" name="zipCode" placeholder=" Newest ZipCode " class="rounded p-1 m-1 text-center" required>
        <input type="text" name="city" placeholder="Newest City " class="rounded p-1 m-1 text-center" required>
        <input type="text" name="nbMaxPlayer" placeholder="Newest Number Max of Players " class="rounded p-1 m-1 text-center" >
        <!-- <input type="hidden" name="_id" value="'.$_id.'"> token csrf xD'-->

        <button type="submit" class="rounded p-1 m-3 border-success" style="max-width: 18rem;"> Update Event </button>
    </form>

</div>

