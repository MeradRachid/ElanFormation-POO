<div class="d-flex justify-content-center">

    <form action="index.php?ctrl=forum&action=addCategory" method="POST" class="m-3">

        <input type="text" name="categoryName" placeholder=" Create a new Category " class="rounded p-1 m-1 text-center" required>

        <button type="submit" class="rounded p-1 m-1 border-success" style="max-width: 18rem;"> Add Category </button>
    </form>

</div>
