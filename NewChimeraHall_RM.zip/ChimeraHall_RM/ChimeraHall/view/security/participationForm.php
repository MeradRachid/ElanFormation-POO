
<?php 

$event = $result["data"]["event"]; 

// var_dump($event);

?>

<h2>Confirmation d'inscription</h2>
<p>Êtes-vous sûr de vouloir vous inscrire à cet évènement ?</p>
<p>Numéro de l'évènement : <?= '# '.$id; ?></p>
<p>Intitulé de l'évènement : <?= $event->getName(); ?></p>
<p>Caractéristiques de l'évènement : <?=$event->getType()->getTitle()?> - Règles <?=$event->getFormat()->getLabel()?> </p>
<form action="index.php?ctrl=forum&action=addParticipation&id=<?=$event->getId()?>" method="post">
    <input type="hidden" name="confirm" value="oui">
    <input type="hidden" name="id" value="<?= $id ?>">
    <button type="submit" class="btn btn-info">Je réserve ma place !</button>
    <a href="index.php?ctrl=forum&action=detailEvent&id=<?=$event->getId()?>" class="btn btn-secondary">Annuler</a>
</form>

<!-- - Code à adapter -  -->
