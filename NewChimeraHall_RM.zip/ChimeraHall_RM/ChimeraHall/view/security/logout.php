<h1> Page de déconnexion </h1>

<p>
    Vous avez bien été déconnecté. <br>
    Au revoir, à très bientôt ! 
</p>