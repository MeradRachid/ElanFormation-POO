<?php
$types = $result["data"]['types'];
$formats = $result["data2"]['formats'];

use Model\Managers\EventManager;
$eventManager = new EventManager;

?>

<div class="d-flex justify-content-center">

    <form action="index.php?ctrl=forum&action=addEvent" method="POST" class="d-flex flex-column m-3">

        <input type="text" name="name" placeholder=" Event Name " class="rounded p-1 m-3 text-center" required>

        <div class="input-group mb-3">
            <select name="type_id" class="form-select form-select-sm text-center" aria-label="form-select-sm example" required>
                <option selected> Event Type </option>
                <?php                
                    foreach($types as $type)
                    { 
                ?>
                     <option value="<?=$type->getId()?>"> # <?=$type->getId()?> : <?= $type->getTitle() ?> </option>
                <?php
                    }
                ?>
            </select>
        </div>

        <div class="input-group mb-3">
            <select name="format_id" class="form-select form-select-sm text-center" aria-label="form-select-sm example" required>
                <option selected> Event Format </option>
                <?php                
                    foreach($formats as $format)
                    { 
                        $label = $format->getLabel(); 
                ?>
                     <option value="<?= $iDn = $eventManager->findIdByLabel($label) ?>"> # <?= $iDn = $eventManager->findIdByLabel($label) ?> : <?= $label ?> </option>
                <?php

                    }
                ?>
            </select>
        </div>

        <input type="date" id="event_date" name="date" placeholder=" Event Date " class="rounded p-1 m-1 text-center">
        <input type="time" id="event_time" name="Time" placeholder=" Event Time " class="rounded p-1 m-1 text-center">
        <input type="text" name="adress" placeholder=" Event Place " class="rounded p-1 m-1 text-center" required>
        <input type="text" name="zipCode" placeholder=" ZipCode " class="rounded p-1 m-1 text-center" required>
        <input type="text" name="city" placeholder=" City " class="rounded p-1 m-1 text-center" required>
        <input type="text" name="nbMaxPlayer" placeholder=" Number Max of Players " class="rounded p-1 m-1 text-center" >
        <!-- <input type="hidden" name="_id" value="'.$_id.'"> token csrf xD'-->

        <button type="submit" class="rounded p-1 m-3 border-success" style="max-width: 18rem;"> Create Event </button>
    </form>

</div>

