<?php
    namespace Model\Entities;

    use App\Entity;

        /**
         * Dans les entities, les propriétés portent le même nom que les champs de la base de données.
         * Sauf pour la clé primaire et les clés étrangères où on enlève le "_id" ou "id_".
         * Chaque Entity va hériter de la classe Entity (dans le dossier App) et toutes les Entities auront exactement le même constructeur : 
         * Il implémente la méthode "hydrate" (de cette même classe Entity)
        */

    final class Event extends Entity
    {
        private $id;
        private $type;
        private $format;
        private $user;
        private $name;
        private $dateTime;
        private $adress;
        private $zipCode;
        private $city;
        private $description;
        private $NbMaxPlayer;
        private $eventLocked;

        public function __construct($data)
        {         
            $this->hydrate($data);        
        }
 
        /**
         * Get the value of (Event) id
         */ 
        public function getId()
        {
                return $this->id;
        }

        /**
         * Set the value of (Event) id
         *
         * @return  self
         */ 
        public function setId($id)
        {
                $this->id = $id;

                return $this;
        }

                /**
         * Get the value of type
         */ 
        public function getType()
        {
                return $this->type;
        }

        /**
         * Set the value of type
         *
         * @return  self
         */ 
        public function setType($type)
        {
                $this->type = $type;

                return $this;
        }
        
        /**
        * Get the value of format_id
        */ 
        public function getFormat()
        {
                return $this->format;
        }

        /**
         * Set the value of format_id
         *
         * @return  self
         */ 
        public function setFormat($format)
        {
                $this->format = $format;

                return $this;
        }

        /**
         * Get the value of user_id
         */ 
        public function getUser()
        {
                return $this->user;
        }

        /**
         * Set the value of user_id
         *
         * @return  self
         */ 
        public function setUser($user)
        {
                $this->user = $user;

                return $this;
        }
        
        /**
         * Get the value of name
         */ 
        public function getName()
        {
                return $this->name;
        }

        /**
         * Set the value of Name
         *
         * @return  self
         */ 
        public function setName($name)
        {
                $this->name = $name;

                return $this;
        }

        public function getDateTime()
        {
            $formattedDate = $this->dateTime->format("l - d/M/Y ~ H\Hi"); // Le symbole "\" permet d'échapper le caractère suivant et le traite comme un caractère littéral. 
            return $formattedDate;
        }

        public function setDateTime($date)
        {
            $this->dateTime = new \DateTime($date);
            return $this;
        }


        /**
         * Get the value of adress
         */ 
        public function getAdress()
        {
                return $this->adress;
        }

        /**
         * Set the value of adress
         *
         * @return  self
         */ 
        public function setAdress($adress)
        {
                $this->adress = $adress;

                return $this;
        }

        /**
         * Get the value of zipCode
         */ 
        public function getZipCode()
        {
                return $this->zipCode;
        }

        /**
         * Set the value of zipCode
         *
         * @return  self
         */ 
        public function setZipCode($zipCode)
        {
                $this->zipCode = $zipCode;

                return $this;
        }

        /**
         * Get the value of city
         */ 
        public function getCity()
        {
                return $this->city;
        }

        /**
         * Set the value of city
         *
         * @return  self
         */ 
        public function setCity($city)
        {
                $this->city = $city;

                return $this;
        }

        /**
         * Get the value of description
         */ 
        public function getDescription()
        {
                return $this->description;
        }

        /**
         * Set the value of description
         *
         * @return  self
         */ 
        public function setDescription($description)
        {
                $this->description = $description;

                return $this;
        }

                /**
         * Get the value of NbMaxPlayer
         */ 
        public function getNbMaxPlayer()
        {
                return $this->NbMaxPlayer;
        }

        /**
         * Set the value of NbMaxPlayer
         *
         * @return  self
         */ 
        public function setNbMaxPlayer($NbMaxPlayer)
        {
                $this->NbMaxPlayer = $NbMaxPlayer;

                return $this;
        }

        /**
         * Get the value of eventLocked
         */ 
        public function getEventLocked()
        {
                return $this->eventLocked;
        }

        /**
         * Set the value of eventLocked
         *
         * @return  self
         */ 
        public function setEventLocked($eventLocked)
        {
                $this->eventLocked = $eventLocked;

                return $this;
        }

    }

?>