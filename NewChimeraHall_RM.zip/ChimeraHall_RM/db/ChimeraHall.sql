-- --------------------------------------------------------
-- Hôte :                        localhost
-- Version du serveur:           5.7.24 - MySQL Community Server (GPL)
-- SE du serveur:                Win32
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Listage de la structure de la base pour chimerahall
CREATE DATABASE IF NOT EXISTS `chimerahall` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `chimerahall`;

-- Listage de la structure de la table chimerahall. coach
CREATE TABLE IF NOT EXISTS `coach` (
  `coach_id` int(11) NOT NULL COMMENT 'user_id du coach',
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `coach_id` (`coach_id`),
  CONSTRAINT `coach_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`id_event`),
  CONSTRAINT `coach_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id_user`),
  CONSTRAINT `coach_ibfk_3` FOREIGN KEY (`coach_id`) REFERENCES `user` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table chimerahall.coach : ~0 rows (environ)
/*!40000 ALTER TABLE `coach` DISABLE KEYS */;
/*!40000 ALTER TABLE `coach` ENABLE KEYS */;

-- Listage de la structure de la table chimerahall. event
CREATE TABLE IF NOT EXISTS `event` (
  `id_event` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `format_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'Creator id_event',
  `name` varchar(90) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `zipCode` varchar(10) NOT NULL,
  `city` varchar(90) NOT NULL,
  `dateTime` datetime DEFAULT CURRENT_TIMESTAMP,
  `description` text,
  `nbMaxPlayer` int(11) DEFAULT '0',
  `eventLocked` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_event`),
  KEY `type_id` (`type_id`),
  KEY `format_id` (`format_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `type` (`id_type`),
  CONSTRAINT `event_ibfk_2` FOREIGN KEY (`format_id`) REFERENCES `format` (`id_format`),
  CONSTRAINT `event_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table chimerahall.event : ~5 rows (environ)
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
REPLACE INTO `event` (`id_event`, `type_id`, `format_id`, `user_id`, `name`, `adress`, `zipCode`, `city`, `dateTime`, `description`, `nbMaxPlayer`, `eventLocked`) VALUES
	(1, 3, 1, 1, 'Invasion Phyrexians', '44, rue des franciscains', '68100', 'Mulhouse', '2023-04-16 09:45:00', 'Description de l\'event', 15, 0);
REPLACE INTO `event` (`id_event`, `type_id`, `format_id`, `user_id`, `name`, `adress`, `zipCode`, `city`, `dateTime`, `description`, `nbMaxPlayer`, `eventLocked`) VALUES
	(2, 1, 3, 3, 'Initiation Commander', '44, rue des franciscains', '68100', 'Mulhouse', '2023-04-18 14:00:00', 'Description de l\'event', 0, 0);
REPLACE INTO `event` (`id_event`, `type_id`, `format_id`, `user_id`, `name`, `adress`, `zipCode`, `city`, `dateTime`, `description`, `nbMaxPlayer`, `eventLocked`) VALUES
	(3, 1, 2, 1, 'Booster Draft FNM', '44, rue des franciscains', '68100', 'Mulhouse', '2023-04-23 18:50:00', 'Description de l\'event', 30, 0);
REPLACE INTO `event` (`id_event`, `type_id`, `format_id`, `user_id`, `name`, `adress`, `zipCode`, `city`, `dateTime`, `description`, `nbMaxPlayer`, `eventLocked`) VALUES
	(4, 1, 1, 1, 'Free For All', '44, rue des Franciscains', '68100', 'Mulhouse', '2023-04-22 16:15:00', NULL, 50, 0);
REPLACE INTO `event` (`id_event`, `type_id`, `format_id`, `user_id`, `name`, `adress`, `zipCode`, `city`, `dateTime`, `description`, `nbMaxPlayer`, `eventLocked`) VALUES
	(5, 2, 3, 1, 'Ashiok, Broyeur de R&ecirc;ves', '44, rue des Franciscains', '68100', 'Mulhouse', '2023-04-27 20:30:00', NULL, 50, 0);
/*!40000 ALTER TABLE `event` ENABLE KEYS */;

-- Listage de la structure de la table chimerahall. format
CREATE TABLE IF NOT EXISTS `format` (
  `id_format` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(90) NOT NULL,
  `rules` text,
  PRIMARY KEY (`id_format`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table chimerahall.format : ~3 rows (environ)
/*!40000 ALTER TABLE `format` DISABLE KEYS */;
REPLACE INTO `format` (`id_format`, `label`, `rules`) VALUES
	(1, 'Standard', '"public/img/Standard.png"');
REPLACE INTO `format` (`id_format`, `label`, `rules`) VALUES
	(2, 'Legacy', '"public/img/Standard.png"');
REPLACE INTO `format` (`id_format`, `label`, `rules`) VALUES
	(3, 'Modern', '"public/img/Standard.png"');
/*!40000 ALTER TABLE `format` ENABLE KEYS */;

-- Listage de la structure de la table chimerahall. participation
CREATE TABLE IF NOT EXISTS `participation` (
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `participation_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`id_event`),
  CONSTRAINT `participation_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table chimerahall.participation : ~0 rows (environ)
/*!40000 ALTER TABLE `participation` DISABLE KEYS */;
REPLACE INTO `participation` (`event_id`, `user_id`) VALUES
	(5, 1);
REPLACE INTO `participation` (`event_id`, `user_id`) VALUES
	(3, 1);
REPLACE INTO `participation` (`event_id`, `user_id`) VALUES
	(4, 1);
REPLACE INTO `participation` (`event_id`, `user_id`) VALUES
	(2, 1);
REPLACE INTO `participation` (`event_id`, `user_id`) VALUES
	(1, 1);
REPLACE INTO `participation` (`event_id`, `user_id`) VALUES
	(4, 4);
REPLACE INTO `participation` (`event_id`, `user_id`) VALUES
	(4, 3);
REPLACE INTO `participation` (`event_id`, `user_id`) VALUES
	(5, 4);
/*!40000 ALTER TABLE `participation` ENABLE KEYS */;

-- Listage de la structure de la table chimerahall. type
CREATE TABLE IF NOT EXISTS `type` (
  `id_type` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(90) NOT NULL,
  `picture` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table chimerahall.type : ~3 rows (environ)
/*!40000 ALTER TABLE `type` DISABLE KEYS */;
REPLACE INTO `type` (`id_type`, `title`, `picture`) VALUES
	(1, 'Match Amical', '"public/img/Standard.png"');
REPLACE INTO `type` (`id_type`, `title`, `picture`) VALUES
	(2, 'Coaching', '"public/img/Standard.png"');
REPLACE INTO `type` (`id_type`, `title`, `picture`) VALUES
	(3, 'Tournoi', NULL);
/*!40000 ALTER TABLE `type` ENABLE KEYS */;

-- Listage de la structure de la table chimerahall. user
CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(90) NOT NULL,
  `role` json DEFAULT NULL,
  `email` varchar(90) NOT NULL,
  `zipCode` varchar(10) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `avatar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `pseudo` (`pseudo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table chimerahall.user : ~3 rows (environ)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
REPLACE INTO `user` (`id_user`, `pseudo`, `role`, `email`, `zipCode`, `password`, `registered`, `avatar`) VALUES
	(1, 'Ajani Goldmane', '"ROLE_ADMIN"', 'chimeraHall@contact.fr', '68100', '$2y$10$Q3l3dJAgxiLAI7D2WA0F9OWOx7MIRdRQ0iZpKsnuSkgp7u/O4b8Vq', '2023-04-13 09:21:28', NULL);
REPLACE INTO `user` (`id_user`, `pseudo`, `role`, `email`, `zipCode`, `password`, `registered`, `avatar`) VALUES
	(2, 'La Boutik Magic', '["ROLE_USER"]', 'adress@mail.fr', '68200', '$2y$10$W/wWBw4RSgQleUGXCOMVS.0dIzh88SjnIfuH4CNG.5u35WCWtMyDS', '2023-04-17 22:12:20', NULL);
REPLACE INTO `user` (`id_user`, `pseudo`, `role`, `email`, `zipCode`, `password`, `registered`, `avatar`) VALUES
	(3, 'Chimeramon', '["ROLE_USER"]', 'test@test.fr', '68120', '$2y$10$zHZgVFPageQv3lVe7Xph.eHBqADLbaWAbT74FS11c/MDceXNAr66y', '2023-04-13 10:27:05', NULL);
REPLACE INTO `user` (`id_user`, `pseudo`, `role`, `email`, `zipCode`, `password`, `registered`, `avatar`) VALUES
	(4, 'Lee Nux', '["ROLE_USER"]', 'chimeraHall@contact.fr', '68210', '$2y$10$HyENSwDZyhlugKQtMAjJt.Qhf8niN1b7qUr7stAeHnfP5l9jCX0w.', '2023-04-27 17:11:41', NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
