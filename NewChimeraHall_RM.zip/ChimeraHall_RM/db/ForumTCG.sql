-- Listage de la structure de la base pour chimeraHall
CREATE DATABASE IF NOT EXISTS `chimeraHall` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `chimeraHall`;

CREATE TABLE User
(
    id_user INT PRIMARY KEY AUTO_INCREMENT,
    role JSON NOT NULL,
    email VARCHAR(90) NOT NULL,
    pseudo VARCHAR(90) UNIQUE NOT NULL,
    zipCode varchar(10) NOT NULL,
    password VARCHAR(255) NOT NULL,
    registered datetime NOT NULL DEFAULT CURRENT_TIMESTAMP, 
    avatar varchar(255) NULL
);

CREATE TABLE IF NOT EXISTS Format 
(
  `id_format` INT PRIMARY KEY AUTO_INCREMENT,
  `label` varchar(90) NOT NULL,
  `rules` text NULL
);

CREATE TABLE IF NOT EXISTS typeEvent 
(
  `id_type` INT PRIMARY KEY AUTO_INCREMENT,
  `title` varchar(90) NOT NULL,
  `picture` varchar(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS Event 
(
  `id_event` INT PRIMARY KEY AUTO_INCREMENT,
  `type_id` INT NOT NULL,
  `user_id` INT NOT NULL,  
  `format_id` INT NOT NULL,  
  `name` varchar(90) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `zipCode` varchar(10) NOT NULL,
  `city` varchar(90) NOT NULL,
  `dateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,  
  `description` text NOT NULL,  
  `nbMaxPlayer` INT NULL DEFAULT '0',
  `eventLocked` BOOLEAN NOT NULL DEFAULT '0',    
  FOREIGN KEY (type_id) REFERENCES typeEvent(id_type),
  FOREIGN KEY (format_id) REFERENCES Format(id_format),
  FOREIGN KEY (user_id) REFERENCES User(id_user)  
);

CREATE TABLE Coach
(
  `event_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `coach_id` INT NOT NULL,    
  FOREIGN KEY (event_id) REFERENCES Event(id_event),
  FOREIGN KEY (user_id) REFERENCES User(id_user),
  FOREIGN KEY (coach_id) REFERENCES User(id_user)
);

CREATE TABLE Participation
(
  `event_id` INT NOT NULL,
  `user_id` INT NOT NULL,  
  FOREIGN KEY (event_id) REFERENCES Event(id_event),
  FOREIGN KEY (user_id) REFERENCES User(id_user)
);
